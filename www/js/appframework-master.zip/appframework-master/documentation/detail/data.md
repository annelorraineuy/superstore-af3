$().data(key,value) gets or sets data-* attributes on an HTML element when value is a string.

This makes a call to $().attr("data-"+key,value).

Please see <a href="#_attr">$().attr()</a>